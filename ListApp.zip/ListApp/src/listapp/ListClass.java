
package listapp;
//ST10315122
import javax.swing.JOptionPane;

public class ListClass {
    //Variables made here that stores the users information
    private String UserName;
    private String Password;
    private String FirstName;
    private String LastName;
    
    //Counter used in code that allows the application to return to menu screen
    public int Counter = 0;
    
    //Variables used in sign up methods
    public String UserNameInput;
    public String PasswordInput;
    public String CheckUserName = "False";
    public String CheckPasswordComplexity = "False";
    
    //Variables used in sign in methods
    public String UserNameInputSignIn;
    public String PasswordInputSignIn;
    public String UserNameMatches = "False";
    public String PasswordMatches = "False";
    

    //Getters and setter are made here below to retrieve and add data to variables
    
    public String getUserName() {
        return UserName;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }
    
    //----------------------1.Sign up------------------------>
    
    public boolean CheckUserName(){ //Method that validates username when users sign up
     if(UserNameInput.length() <=5 && UserNameInput.contains("_")){
         CheckUserName = "True";
          setUserName(UserNameInput);
     }else{
         CheckUserName = "False";
     }
        return false;
    }
    
    public boolean CheckPasswordComplexity(){ //Method that validates the password when the users sign up
     if(PasswordInput.length() > 8  && PasswordInput.matches(".*[A-Z].*") && PasswordInput.matches(".*[a-z].*") && PasswordInput.matches(".*[!@#$%^&*].*")){
         CheckPasswordComplexity = "True";
         setPassword(PasswordInput);
     }else{
         CheckPasswordComplexity = "False";
         
     }
        return false;
    }
    
    public void RegisterUserName(){ //Method that displays error messaging for username
        if (CheckUserName == "True"){
             JOptionPane.showMessageDialog(null, "Username successfully captured");
             
        }else{
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more then 5 characters in length");   //Error messages displayed
        }
    }
    
    public void RegisterPassword(){ //Method that displays error messaging for password
        if (CheckPasswordComplexity == "True"){
            JOptionPane.showMessageDialog(null, "Password successfully captured");
             
        }else{
             JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character");   //Error messages displayed
        }
    }
    //----------------------1.Sign in------------------------>
    
    public boolean LoginUserName(){ //Method that checks if username matches stored usernames when users sign in
     if(UserNameInputSignIn.equals(UserName)){
         UserNameMatches = "True";
     }else{
         UserNameMatches = "False";
     }
        return false;
    }
    
    public boolean LoginPassword(){ //Method that checks if username matches stored usernames when users sign in
     if(PasswordInputSignIn.equals(Password)){
         PasswordMatches = "True";
     }else{
         PasswordMatches = "False";
     }
        return false;
    }
    
    String ReturnLoginStatus(){ //Method that displays error messaging for username and password when users sign in
        if (UserNameMatches == "True"){
            if (PasswordMatches == "True"){
                 JOptionPane.showMessageDialog(null, "Username and password is corrrect");  //Error messages displayed
                      JOptionPane.showMessageDialog(null, "Welcome " + FirstName + " " + LastName + " it is great to see you again");  //Error messages displayed
            }else if(PasswordMatches == "False"){
                JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again");
                Counter = Counter + 1;
            }
        }else if(UserNameMatches == "False"){
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again");
            Counter = Counter + 1;
        }
        return null;
    }
   
    public void Login(){  //Login method created here using while loop with if statements
        do{
          Counter = 0;
          String OptionInput = JOptionPane.showInputDialog("Please select one of the following(Option number only): \n1. Sign in \n2.Create account \n3.To return to menu \n4. Exit app"); //Menu / GUI
          int Option = Integer.parseInt(OptionInput);
          
          if (Option == 1){ //If statement for menu options
               UserNameInputSignIn = JOptionPane.showInputDialog("Enter in your username: "); //Prompts the user for information
               
              if (UserNameInputSignIn == UserNameInputSignIn){
                 PasswordInputSignIn = JOptionPane.showInputDialog("Enter in your password: ");  //Prompts the user for information
                 LoginUserName(); //Sign in method for checking username called
                 LoginPassword(); //Sign in method for checking password called
                 ReturnLoginStatus(); //Sign in method for Error messaging called 
                  
              }
          }else if (Option == 2){ 
           UserNameInput = JOptionPane.showInputDialog("Enter in a new username: "); //Prompts the user for information
           
         if (UserNameInput == UserNameInput){
             CheckUserName(); //Sign up Method for validating username called
             RegisterUserName(); //Sign up  method for error messaging called
             
             if (CheckUserName == "True"){
                 PasswordInput = JOptionPane.showInputDialog("Enter in a password: "); //Prompts the user for information
                 CheckPasswordComplexity(); //Sign up Method for validating password called
                 RegisterPassword(); //Sign up  method for error messaging called
                 
                 if (CheckPasswordComplexity == "True"){
                 if(CheckUserName == "True" && CheckPasswordComplexity == "True"){       
         String FirstNameInput = JOptionPane.showInputDialog("Enter in your first name: "); //Prompts the user for information
         setFirstName(FirstNameInput);
         String LastNameInput = JOptionPane.showInputDialog("Enter in your last name: "); //Prompts the user for information
         setLastName(LastNameInput);
         JOptionPane.showMessageDialog(null, "New account has been created successfully"); //Error messages displayed
         Counter = Counter + 1; //Code that allows the application to return to menu screen
         
                 }
                 } else if(CheckPasswordComplexity == "False"){
                     Counter = Counter +1; //Code that allows the application to return to menu screen
                     
                 }
             } else if(CheckUserName == "False"){
                 Counter = Counter + 1; //Code that allows the application to return to menu screen
                 
             }
         }
          } else if (Option == 3){ //Return to menu
              continue;
              
          } else if (Option == 4){
              JOptionPane.showMessageDialog(null, "You are now exiting the lists app!");
              break;
              
          }
      }while(Counter == 1); //Code that keeps the while loop / application always running unless closed by the user
    }
    
    
    
    //Main method created here below
    public void Main(){
        Login();
    }
    
}

