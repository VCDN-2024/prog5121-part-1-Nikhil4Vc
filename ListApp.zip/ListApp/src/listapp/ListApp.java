
package listapp;
//ST10315122
import javax.swing.JOptionPane;

public class ListApp {

    
    public static void main(String[] args) {
        
        
        ListClass List = new ListClass();
        
        
     // String OptionInput = JOptionPane.showInputDialog("Please select one of the following(Option number only): \n1. Sign in \n2.Create account \n3.To return to menu");
     // int Option = Integer.parseInt(OptionInput);
      
     List.Main(); //Main method being called
    }
    
}
